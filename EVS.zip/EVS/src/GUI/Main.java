package GUI;

import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException
	{
	dob i = new dob();
	i.initializeYears();
	welcome c = new welcome();
	//Login a = new Login();
	//signinMain b = new signinMain();
	//cities d = new cities();
	//homepage e = new homepage();
	//filingSave f = new filingSave();
	//f.getUserLogin("helloo","3");
	//database g = new database();
	//homepage h = new homepage();
	}
	}
