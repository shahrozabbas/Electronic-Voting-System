package GUI;

public class Objectives {
/*
 
 
 NEW Objectives:
 	save account detials in a file with the username of the user
 	update the users file and add the user and his password in the next field
 	
 1	Login Page, mess around with the placement
 2	Create Account/Signin
 	2.1		javafx.Calendar
 	2.6		Job, is this necessary or just a filler?
 	2.7 	make a cities, provinces and districts interface and use it
 			Use it in signup for the address selection
 	2.11	Separate fields that need verification into classes
 			Then use inputVerifier
 			Figure out how
 			DO this for the following
 				CNIC
 				Number
 				DOB, can i add a popup with the correct format? or sue calendar with verification
				Email
 4	Define Objectives of Project 
 5	Saving accounts in file???
 6 	Voting Interface
 
 Punjab=1
 Sindh=2
 Balochistan=3
 KPK=4
 Gilgit=5
 Azad Jammu=6
 
 Username
 Password
*/
}
