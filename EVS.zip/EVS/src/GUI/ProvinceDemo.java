package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.io.*;
 
public class ProvinceDemo extends JFrame implements ActionListener {
     
    private static final long serialVersionUID = 1L;
    JButton select;
    JComboBox province, cities;
    Panel center, south, north, east;
    JLabel label;
    static boolean selectPressed;
    public ProvinceDemo(String title) {
        super(title);
        select = new JButton("Select");
        center = new Panel();
        south = new Panel();
        north = new Panel();
        east = new Panel();
        south.add(select, BorderLayout.CENTER);
        province = new JComboBox();
        try {
            File file = new File("provinces.txt");
            BufferedReader in = new BufferedReader(new FileReader(file));
            String str;
 
            while ((str = in.readLine()) != null) {
            	province.addItem(str);
            }
        } catch (IOException e) {
            System.out.println("An exception occured " + e);
            
            return;
        }
         
 
        center.add(province);
         
        cities = new JComboBox();
        east.add(cities);
        label = new JLabel("Select District");
        north.add(label);
         
        Container contentPane = getContentPane();
        contentPane.add(center, BorderLayout.CENTER);
        contentPane.add(south, BorderLayout.SOUTH);
        contentPane.add(north, BorderLayout.NORTH);
        contentPane.add(east, BorderLayout.EAST);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        MyListener listener = new MyListener(province, cities);
        province.addActionListener(listener);
        select.addActionListener(this);
        setLocationRelativeTo(null);
        setSize(450,250);
    }
    
    void setDistrict()
    {
		userInfo.Users_city=(String) cities.getSelectedItem();
		userInfo.Users_province=(String) province.getSelectedItem();
		selectPressed=true;
        //signin2.district_city.setText(userInfo.Users_city);
        //signin2.district_province.setText(userInfo.Users_province);
       // signin2.district_province.setEditable(false);
       // signin2.district_city.setEditable(false);
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==select)
		{
			if(province.getSelectedItem()==null||cities.getSelectedItem()==null)
			{
				JOptionPane.showMessageDialog(north, "Please Select District!","Error", JOptionPane.WARNING_MESSAGE);
			}
			else
			{
				userInfo.Users_province=(String) province.getSelectedItem();
				userInfo.Users_city=(String) cities.getSelectedItem();
				System.out.println(userInfo.Users_province);
	        	setVisible(false);
            	dispose();
            	setDistrict();
			}
		}
		
	}
 
  /*  public static void main(String[] args) {
        JFrame f = new ProvinceDemo("Select District");
        f.setSize(450, 200);
        f.setVisible(true);
    }*/
 
}