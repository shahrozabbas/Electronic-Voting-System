package GUI;

import java.io.IOException;

public class signinMain {
signinMain() throws IOException
{
    signin1 frame = new signin1();
}}
