package GUI;

public abstract class gender {
	public static String[] genderList = new String[] {"Select", "Male", "Female", "Unspecified"};
}
