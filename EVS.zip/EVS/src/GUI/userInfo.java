package GUI;

public abstract class userInfo {
	public static String Users_name= new String();
	public static String Users_username= new String();
	public static String Users_password= new String();
	public static String Users_cnic= new String();
	public static String Users_dob_date= new String();
	public static String Users_dob_month= new String();
	public static String Users_dob_year= new String();
	public static String Users_gender= new String();
	public static String Users_religion= new String();
	public static String Users_fatherName= new String();
	public static String Users_email= new String();
	public static String Users_phone= new String();
	public static String Users_province= new String();
	public static String Users_city= new String();
	public static String Users_extra= new String();
}
