package GUI;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.*;

public class welcome implements ActionListener {
	String text = new String();
	JFrame welcomeFrame = new JFrame();
	
	JFrame optionFrame = new JFrame();
	JPanel optionPanel = new JPanel();
	JLabel optionText = new JLabel();
	JButton signup = new JButton();
	JButton login = new JButton();
	Panel center, south, north, east, west;
	welcome()
	{
		JOptionPane.showMessageDialog(welcomeFrame,"Welcome to Pakistan Voters Portal!");
        center = new Panel();
        south = new Panel();
        north = new Panel();
        east = new Panel();
        west = new Panel();
		
		optionText.setText("<html><body><center>Click on Sign-Up to Register<br>If you already have an account click on Login<br></body></html>");
		signup.setText("Sign-Up");
		login.setText("Login");
		//optionText.setText("<html><p style=\"width:270px\">"+text+"</p></html>");
		//String optionText = "<html><body><center>Click on Sign-Up to Register<br>If you already have an account click on Login<br></body></html>";
		//String signupText = "Sign-In";
		//String loginText = "Login";
		optionText.setBounds(100, 100, 80, 25);
		login.setBounds(135, 150, 80, 25);
		signup.setBounds(70, 150, 80, 25);

		north.add(optionText);
		center.add(signup);
		east.add(login);

        optionPanel.add(north, BorderLayout.NORTH);
        optionPanel.add(center, BorderLayout.CENTER);
        optionPanel.add(south, BorderLayout.SOUTH);
        optionPanel.add(east, BorderLayout.EAST);
        
		optionFrame.add(optionPanel);
		optionFrame.setVisible(true);
		optionFrame.setSize(350, 140);
        signup.addActionListener(this);
        login.addActionListener(this);
		optionFrame.setLocationRelativeTo(null);
	}
	  public void actionPerformed(ActionEvent e) {
	        if (e.getSource() == login) {
	        	optionFrame.setVisible(false);
            	optionFrame.dispose();
	        	try {
					Login a = new Login();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
	        }
	        else if (e.getSource()==signup) {
	        	try {
					signinMain b = new signinMain();
		        	optionFrame.setVisible(false);
	            	optionFrame.dispose();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	        }
}
	  }
