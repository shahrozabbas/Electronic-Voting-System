package GUI;

public abstract class religion {
	public static String[] religionList = new String[] {"Select", "Islam", "Christian", "Jew", "Sikh", "Hindu", "Parsi", "Atheist"};;
}
