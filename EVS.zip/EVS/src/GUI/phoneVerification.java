package GUI;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class phoneVerification {
	//https://www.tutorialspoint.com/how-can-we-make-jtextfield-accept-only-numbers-in-java
	/*
	phoneNumber.addKeyListener(new KeyAdapter() {
		public void keyPressed1(KeyEvent e) {
			String value =phoneNumber.getText();
			int len1 = value.length();
			if (e.getKeyChar()>='0' && e.getKeyChar()<='9') {
				phoneNumber.setEditable(true);
				phoneError.setText("");
			} else {
				phoneNumber.setEditable(false);
				phoneError.setText("*Enter Numbers Only*");
			}
		}
	});
	*/
}
