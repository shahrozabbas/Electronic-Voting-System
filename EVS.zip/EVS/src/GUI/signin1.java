package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import GUI.signin2.customFocusListener;

public class signin1 implements ActionListener{
	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	JLabel username = new JLabel();
	JLabel pwd = new JLabel();
	
	JButton next = new JButton("Next");
	JTextField usernameText = new JTextField("");
	JTextField pwdText = new JTextField("");

	String usernameCheck = new String();
	String passwordCheck = new String();
	
	static String username_signin1;
	static String password_signin1;
	
	signin1() throws IOException{

		addActionEvents();
		
		username.setText("Username:");
		username.setBounds(10, 20, 100, 25);
		pwd.setText("Password:");
		pwd.setBounds(10, 50, 100, 25);
		next.setText("Next");
		next.setBounds(200, 90, 60, 30);
		
		usernameText.setBounds(100, 20, 165, 25);
		pwdText.setBounds(100, 50, 165, 25);
		panel.setLayout(null);
		panel.add(username);
		panel.add(pwd);
		panel.add(usernameText);
		panel.add(pwdText);
		panel.add(next);

		frame.setTitle("Sign-Up");
		frame.setSize(300, 180);
		frame.add(panel);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==next){
			sigin_verification verificator = null;
			//boolean username_error=false;
			//boolean password_error=false;
			if(usernameText.getText().isEmpty()||pwdText.getText().isEmpty())
			{
				JLabel empty_error = new JLabel("A field is empty               ");
				empty_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(panel, empty_error, "Error", JOptionPane.WARNING_MESSAGE);
			}
			else if(usernameText.getText().length()<=5)
			{
				JLabel username_error = new JLabel("Username must contain atleast 6 characters");
				username_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(panel, username_error, "Error", JOptionPane.WARNING_MESSAGE);
			}
			else if(pwdText.getText().length()<=7)
			{
				JLabel password_error = new JLabel("Password must contain atleast 8 characters");
				password_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(panel, password_error, "Error", JOptionPane.WARNING_MESSAGE);
			}
			else
			{
				String username = usernameText.getText();
				String password = pwdText.getText();
				userInfo.Users_username=username;
				userInfo.Users_password=password;
				System.out.println(userInfo.Users_username+"\n"+userInfo.Users_password);
	        	frame.setVisible(false);
	        	frame.dispose();
	        	try {
					signin2 a = new signin2();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	} /*
	public class customFocusListener implements FocusListener{
    	public void focusGained(FocusEvent e) {
    		if(e.getSource()==usernameText&&(usernameText.getText().contentEquals("6 Letters Minimum")))
    		{usernameText.setText("");}
    		if(e.getSource()==pwdText&&(pwdText.getText().contentEquals("8 Characters Minimum")))
    		{pwdText.setText("");}
    	}
    	
    	public void focusLost(FocusEvent e) {
    		if (usernameText.getText().equals(""))
    		{usernameText.setText("6 Letters Minimum");}
    		if (pwdText.getText().equals(""))
    		{pwdText.setText("8 Characters Minimum");}
    	}

    }*/
	  public void addActionEvents() {
        next.addActionListener(this);
        //usernameText.addFocusListener(new customFocusListener());
        //pwdText.addFocusListener(new customFocusListener());
	    }

}
