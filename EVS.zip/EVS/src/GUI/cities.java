package GUI;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class cities {
	cities() throws IOException{
		int ch;
		int ca;
		String temp1="";
		char temp2;
		String[] Punjab = new String[41];
		String[] Sindh = new String[23];
		String[] Balochistan = new String[27];
		String[] Kpk = new String[29];
		String[] Gilgit = new String[6];
		String[] Kashmir = new String[65];
		String Islamabad;
    	int punj=0, sin=0, bal=0, kp=0, gil=0, kash=0, fed=0;
		int count=0;
		BufferedReader s = null;
        // check if File exists or not 
        FileReader fr=null; 
        FileReader fa=null;
        try
        { 
            fr = new FileReader("cities.txt"); 
        } 
        catch (FileNotFoundException fe) 
        { 
            System.out.println("File not found"); 
        } 
        // read from FileReader till the end of file 
        while ((ch=fr.read())!=-1) 
        {
        	char test=(char)ch;
        	//System.out.print(test);
        	if (test== '1')
        	{
        		punj++;
    		}
        	else if (test== '2')
        	{
        		sin++;
    		}
        	else if (test== '3')
        	{
        		bal++;
    		}
        	else if (test== '4')
        	{
        		kp++;
    		}
        	else if(test=='5')
        	{
        		gil++;
        	}
        	else if(test=='6')
        	{
        		kash++;
        	}
        	else if(test=='7')
        	{
        		fed=1;
        	}
        }
        System.out.println("Balochistan"+bal);
        System.out.println("Punjab"+punj);
        System.out.println("Sindh"+sin);
        System.out.println("KPK"+kp);
        System.out.println("Gilgit"+gil);
        System.out.println("Kashmir"+kash);
        
        fr.close();}
		public void cityPwise() {
			
		}
}



