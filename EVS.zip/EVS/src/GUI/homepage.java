package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.*;

public class homepage implements ActionListener{
	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	
	JButton accountDetails = new JButton("Account Details");
	JButton voteButton = new JButton("<html><center>Click Here<br/>to Cast Vote</html>");
	
	String welcomeUserMessage = new String("Welcome " +userInfo.Users_name);
	//JLabel homeMessage = new JLabel("<html><center>" + welcomeUserMessage + "</center></html>");
	JLabel homeMessage = new JLabel(welcomeUserMessage, SwingConstants.CENTER);
	
	homepage()
	{
		panel.setLayout(null);
		
		homeMessage.setBounds(0, 20, 335, 10);
		voteButton.setBounds(20, 95, 130, 50);
		accountDetails.setBounds(170, 95, 130, 50);
		//accountDetails.setBounds(x, y, width, height);
		
		voteButton.addActionListener(this);
		accountDetails.addActionListener(this);
		
		panel.add(homeMessage);
		panel.add(accountDetails);
		panel.add(voteButton);
		
		frame.add(panel);
		
        frame.setTitle("Homepage");
        frame.setSize(335, 250);
		frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==voteButton)
		{
			voteStation a = new voteStation();
		}
		else if(e.getSource()==accountDetails)
		{
			try {
				accountDetails b = new accountDetails();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
	}
}
