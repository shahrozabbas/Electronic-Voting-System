package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LoginFrame extends JFrame implements ActionListener {

    Container container = getContentPane();
    JLabel userLabel = new JLabel("Username");
    JLabel passwordLabel = new JLabel("Password");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("Login");
    JButton resetButton = new JButton("Clear");
    JCheckBox showPassword = new JCheckBox("Show Password");
    static String filepath="Users.txt";
    boolean found = true;
    String gotPassword;
    String gotUsername;

	sigin_verification verificator = new sigin_verification();
	

    LoginFrame() {
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();

    }

    public void setLayoutManager() {
        container.setLayout(null);
    }

    public void setLocationAndSize() {
        userLabel.setBounds(50, 20, 100, 30);
        passwordLabel.setBounds(50, 60, 100, 30);
        userTextField.setBounds(150, 20, 150, 30);
        passwordField.setBounds(150, 60, 150, 30);
        showPassword.setBounds(150, 90, 150, 30);
        loginButton.setBounds(50, 140, 100, 30);
        resetButton.setBounds(200, 140, 100, 30);
    }

    public void addComponentsToContainer() {
        container.add(userLabel);
        container.add(passwordLabel);
        container.add(userTextField);
        container.add(passwordField);
        container.add(showPassword);
        container.add(loginButton);
        container.add(resetButton);
    }

    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
    }


    @SuppressWarnings("deprecation")
	@Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
        	try {
				boolean foundAccount = searchID(userTextField.getText(), passwordField.getText());
				if (foundAccount==true)
				{
					System.out.println("Account found");
					setVisible(false);
					dispose();
					homepage a = new homepage();
				}
				else
				{
					System.out.println("Account not found");
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	/*
        	gotUsername = userTextField.getText();
        	userInfo.Users_username=gotUsername;
        	gotPassword = passwordField.getText();
			userInfo.Users_password=gotPassword;
			Scanner s;
			System.out.println(gotUsername+gotPassword);
        	String login_username = userTextField.getText();
        	String login_password = passwordField.getText();
        	System.out.println(login_username);
        	/*if(login_username!=userInfo.Users_username)
        	{
        		JLabel an_error = new JLabel("Incorrect Username");
				an_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(container, an_error, "Error", JOptionPane.WARNING_MESSAGE);
        	}
        	else if(login_password!=userInfo.Users_password)
        	{
        		JLabel an_error = new JLabel("Password is Incorrect");
				an_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(container, an_error, "Error", JOptionPane.WARNING_MESSAGE);
			
        	}
    		if (login_username==userInfo.Users_username&&login_password==userInfo.Users_password)
        	{
    			setVisible(false);
    			dispose();
    			JLabel an_error = new JLabel("Login Successful!");
				an_error.setHorizontalAlignment(SwingConstants.CENTER);
				JOptionPane.showMessageDialog(container, an_error, "Login Successful", JOptionPane.WARNING_MESSAGE);
				homepage a = new homepage();
        	}
        	/*try {
				found=verificator.login_verification(gotUsername, gotPassword);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}*/
        	
        }
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } 
            else {
                passwordField.setEchoChar('*');
            }
        }  
    }
    
    public boolean searchID(String username, String password) throws IOException {
    boolean flag = false;
    String UserRecord ="users.txt";
	Scanner search = new Scanner(new BufferedReader(new FileReader(UserRecord)));
    search.useDelimiter("[.]");
    while (search.hasNextLine()){
    	String USERNAME = search.next();
    	String PASSWORD = search.next();
    	System.out.println("Username: "+USERNAME);
    	System.out.println("Password: "+PASSWORD);
    	if (USERNAME.equals(username)) {
    		System.out.println("Username found");
			userInfo.Users_name=USERNAME;
    		if(PASSWORD.equals(password))
    		{
    			search.close();
    			Scanner search1 = new Scanner(new BufferedReader(new FileReader(UserRecord)));
    			System.out.println("Password found");
    			search1.useDelimiter(",");
    			String shift = search1.next();
    	    	userInfo.Users_name=search1.next();
    	    	System.out.println("username: "+userInfo.Users_name);
    	    	userInfo.Users_gender=search1.next();
    	    	System.out.println("cnic: "+userInfo.Users_cnic);
    	    	userInfo.Users_religion=search1.next();
    	    	System.out.println(userInfo.Users_gender);
    	    	userInfo.Users_fatherName=search1.next();
    	    	System.out.println(userInfo.Users_religion);
    	    	userInfo.Users_email=search1.next();
    	    	userInfo.Users_phone=search1.next();
    	    	userInfo.Users_dob_date=search1.next();
    	    	userInfo.Users_province=search1.next();
    	    	userInfo.Users_dob_month=search1.next();
    	    	userInfo.Users_dob_year=search1.next();
    	    	userInfo.Users_city=search1.next();
    			flag=true;
    		}
    		else
    		{System.out.println("Password not found");}
    		break;
    	}
	}
    return flag;
}
}
