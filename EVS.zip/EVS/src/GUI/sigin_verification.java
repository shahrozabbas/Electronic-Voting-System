package GUI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

import java.util.Scanner;
import java.util.regex.Matcher; 
import java.util.regex.Pattern; 

public class sigin_verification {
	
	public boolean empty_check(String a)
	{
		if (a.isEmpty())
		{
			return false;
		}
		return true;	
	}
	public boolean cnic_verification(String a) {
		if (a.matches("[0-9]+") && a.length() == 13)
		{
			return true;
		}
		else
			return false;
	}
	public boolean phone_verification(String a) {
		if (a.matches("[0-9]+") && a.length() == 14)
		{
			return true;
		}
		else
			return false;
	}
	public boolean email_verification(String a){
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$"; 
                  
	Pattern pat = Pattern.compile(emailRegex); 
	if (a == null) 
	return false; 
	return pat.matcher(a).matches(); 
	}	
	
	public boolean name_verification(String a) {
		if (a.matches("[a-zA-Z ]+"))
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean date_verification(Integer date, Integer month, Integer year) 
	{
		/*
		if(date!="Date"||month!="Month"||year!="Year") {
		if(year_converted>1910)
		{
			return true;
		}
		else if(month_converted<1 || month_converted>12)
		{
			return true;
		}
		else if(date<1 || date>31)
		{
			return true;
		}
		else if((date<1 || date>=30) && (date==2||date==4||date==6||date==9||date==11))
		{
			return true;
		}
		}*/
		if(date==null&month==null&year==null)
		return false;
		else
			return true;
	}
	public boolean login_verification(String username_input, String password_input) throws IOException
	{
		String username="";
		String password="";
		FileReader fr = new FileReader("Users.txt");
		int i;
		while((i=fr.read())!=-1)
		{
			System.out.println((char)i);
			username=username+i;
			if (i=='.')
			{
				while(i!=' ')
				{
				password=password+i;
				}}
		}
		System.out.println(username+password);
		return false;
	}
	public boolean religion_verificator(String religion)
	{
		if(religion=="Select")
			return false;
		else
			return true;
	}
	public boolean gender_verificator(String gender)
	{
		if(gender=="Select")
			return false;
		else
			return true;
	}/*
	public boolean username_verificator(String username)
	{
		if(username.length()<6)
			return false;
		else
			return true;
	}
	public boolean password_verificator(String password)
	{
		if(password.length()<8)
			return false;
		else
			return true;
	}*/
}
