package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
//import javafx.scene.*;
//import javafx.scene.layout.StackPane;

public class signin2 extends userInfo implements ActionListener{
	//Frames+Panels
	JFrame frame = new JFrame();
	JPanel panel = new JPanel();
	
	//Labels
	JLabel cnic = new JLabel();
	JLabel name = new JLabel();
	JLabel dateOfBirth = new JLabel();
	JLabel dob_dash1 = new JLabel("/");
	JLabel dob_dash2 = new JLabel("/");
	JLabel genderText = new JLabel();
	JLabel religionText = new JLabel();
	JLabel father = new JLabel();
	JLabel phone = new JLabel();
	JLabel phoneError = new JLabel();
	JLabel email = new JLabel();
	JLabel district = new JLabel();
	JLabel province_name = new JLabel();
	JLabel city_name = new JLabel();
	
	//Buttons
	JButton signup = new JButton("SignUp");
	JButton districtSelector = new JButton();
	
	//RHS of Display (TextFields+ComboBoxes+others in order)
	JTextField nameText = new JTextField(36);
	JTextField cnicNumber = new JTextField("13 Digits", 13);
	JTextField dobText = new JTextField();
	//String[] genderList = new String[] {"Male", "Female", "Unspecified"};
	JComboBox<String> genderBox = new JComboBox<>(gender.genderList);
	//String[] religionList = new String[] {"Islam", "Christian", "Jew", "Sikh", "Hindu", "Parsi", "Atheist"};
	JComboBox<String> religionBox = new JComboBox<>(religion.religionList);
	JTextField fatherName = new JTextField();
	JTextField phoneNumber = new JTextField("14 Digits", 14);
	JTextField emailText = new JTextField("example@email.com");
	JTextField district_province = new JTextField();
	JTextField district_city = new JTextField();
	JComboBox<Integer> day = new JComboBox<>(dob.dateList1);
	JComboBox<Integer> month = new JComboBox<>(dob.monthList);
	JComboBox<Integer> year = new JComboBox<>(dob.yearList);
	
	sigin_verification verificator = new sigin_verification();
	
	boolean distUsed=false;
	
	signin2() throws IOException
	{
		//DatePicker datePicker = new DatePicker();
		name.setText("Name:");
		name.setBounds(10, 20, 100, 25);
		cnic.setText("CNIC:");
		cnic.setBounds(10, 50, 100, 25);
		dateOfBirth.setText("Date of Birth:");
		dateOfBirth.setBounds(10, 80, 100, 25);
		dob_dash1.setBounds(150, 80, 100, 25);
		dob_dash2.setBounds(212, 80, 100, 25);
		genderText.setText("Gender:");
		genderText.setBounds(10, 110, 100, 25);
		religionText.setText("Religion:");
		religionText.setBounds(10, 140, 100, 25);
		father.setText("Father Name:");
		father.setBounds(10, 170, 100, 25);
		phone.setText("Phone Number:");
		phone.setBounds(10, 200, 100, 25);
		email.setText("Email:");
		email.setBounds(10, 230, 100, 25);
		district.setBounds(10, 260, 100, 25);
		district.setText("District:");
		province_name.setBounds(10, 290, 100, 25);
		province_name.setText("Province:");
		city_name.setBounds(10, 320, 100, 25);
		city_name.setText("City:");
		
	    
		
		nameText.setBounds(100, 20, 182, 25);
		cnicNumber.setBounds(100, 50, 182, 25);
		day.setBounds(100, 80, 42, 25);
		month.setBounds(164, 80, 42, 25);
		year.setBounds(224, 80, 58, 25);
		genderBox.setBounds(100, 110, 182, 25);
		religionBox.setBounds(100, 140, 182, 25);
		fatherName.setBounds(100, 170, 182, 25);
		phoneNumber.setBounds(100, 200, 182, 25);
		emailText.setBounds(100, 230, 182, 25);
		districtSelector.setBounds(100, 260, 182, 25);
		districtSelector.setText("Click here to select");
		district_province.setBounds(100, 290, 182, 25);
		district_city.setBounds(100, 320, 182, 25);
		district_province.setText("");
		district_city.setText("");
		signup.setBounds(100,350, 165,25);
		//signup.setBounds(135, 100, 80, 25);
		
		
		panel.setLayout(null);
		panel.add(name);
		panel.add(cnic);
		panel.add(dateOfBirth);
		panel.add(day);
		panel.add(dob_dash1);
		panel.add(month);
		panel.add(dob_dash2);
		panel.add(year);
		panel.add(nameText);
		panel.add(cnicNumber);
		panel.add(dobText);
		panel.add(genderText);
		panel.add(genderBox);
		panel.add(religionText);
		panel.add(religionBox);
		panel.add(father);
		panel.add(fatherName);
		panel.add(phone);
		panel.add(phoneNumber);
		panel.add(email);
		panel.add(emailText);
		panel.add(district);
		panel.add(district_province);
		panel.add(district_city);
		panel.add(province_name);
		panel.add(city_name);
		panel.add(districtSelector);
		panel.add(signup);
		//panel.add(signup);
		
				
		frame.setTitle("Sign-Up");
		frame.setSize(400, 700);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
        frame.setLocationRelativeTo(null);
		
        addActionEvent();
        
		String username="testuser";
		String password="testpass";
		}
	
	 public void addActionEvent() {
		 signup.addActionListener(this);
		 districtSelector.addActionListener(this);
		 cnicNumber.addFocusListener(new customFocusListener());
		 phoneNumber.addFocusListener(new customFocusListener());
		 emailText.addFocusListener(new customFocusListener());
	    }


        @Override
        public void actionPerformed(ActionEvent e) {
			if(e.getSource()==signup)
			{
				boolean empty_field;//total 9 of these
				boolean name_error;
				boolean cnic_error;
				boolean phone_error;
				boolean email_error;
				boolean father_error;
				boolean dob_error;
				
				//empty checks
				empty_field=verificator.empty_check(nameText.getText());
				//name
				name_error=verificator.name_verification(nameText.getText());
				System.out.println(name_error);//Debug
				
				//cnic
				cnic_error=verificator.cnic_verification(cnicNumber.getText());
				System.out.println(cnic_error);//Debug
				
				//no checks
				
				//father name
				father_error=verificator.name_verification(fatherName.getText());
				System.out.println(father_error);//Debug
				
				//email
				email_error=verificator.email_verification(emailText.getText());
				System.out.println(email_error);
				
				//phone
				phone_error=verificator.phone_verification(phoneNumber.getText());
				System.out.println(phone_error);//Debug
				
				//dob
				dob_error=verificator.date_verification((Integer)day.getSelectedItem(), (Integer)month.getSelectedItem(), (Integer)year.getSelectedItem());
				System.out.println(dob_error);
				
				if(name_error==false||dob_error==false||phone_error==false||email_error==false||father_error==false||cnic_error==false||name_error==false||empty_field==false)
				{
					JLabel an_error = new JLabel("Data has been input incorrectly");
					an_error.setHorizontalAlignment(SwingConstants.CENTER);
					JOptionPane.showMessageDialog(frame, an_error, "Error", JOptionPane.WARNING_MESSAGE);
				}
				else
				{
					String tempname=nameText.getText();
					String tempcnic=cnicNumber.getText();
					String tempgender=(String)(genderBox.getSelectedItem());
					String tempreligion=(String)(religionBox.getSelectedItem());
					String tempfatherName=fatherName.getText();
					String tempemail=emailText.getText();
					String tempphone=phoneNumber.getText();
					int tempdob_date=(Integer)day.getSelectedItem();
					int tempdob_month=(Integer)month.getSelectedItem();
					int tempdob_year=(Integer)year.getSelectedItem();
					String temp_province=userInfo.Users_province;
					String temp_city=userInfo.Users_city;
					
					String UserRecord="users.txt";
					try {
						BufferedWriter myWriter= new BufferedWriter(new FileWriter(UserRecord, true));
						myWriter.write(userInfo.Users_username+"."+userInfo.Users_password+".,");
						myWriter.write(tempname+","+tempcnic+",");
						myWriter.write(tempgender+","+tempreligion+",");
						myWriter.write(tempfatherName+","+tempemail+",");
						myWriter.write(tempphone+","+tempdob_date+",");
						myWriter.write(tempdob_month+","+tempdob_year+",");
						myWriter.write(temp_province+","+temp_city+",\n");
						myWriter.close();
						/*userInfo.Users_name=tempname;
						userInfo.Users_cnic=tempcnic;
		    	    	userInfo.Users_gender=tempgender;
		    	    	userInfo.Users_religion=tempreligion;
		    	    	userInfo.Users_fatherName=tempfatherName;
		    	    	userInfo.Users_email=tempemail;
		    	    	//userInfo.Users_dob_date=tempdob_date;
		    	    	//userInfo.Users_dob_month=tempdob_month;
		    	    	//userInfo.Users_dob_year=tempdob_year;
		    	    	userInfo.Users_province=temp_province;
		    	    	userInfo.Users_city=temp_city;*/
					} 
					catch (IOException e2) {
						e2.printStackTrace();
					}
					
					frame.setVisible(false);
					frame.dispose();
					
					System.out.println(userInfo.Users_username+userInfo.Users_password);
					JOptionPane.showMessageDialog(frame, "<html><center>Account Sucessfully Created<br>You may now login</html>", "Success", JOptionPane.INFORMATION_MESSAGE);
					try {
						Login a = new Login();
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				//Users_district=(String)(districtSelector.getDistrict());
			}
			if (e.getSource()==districtSelector)
			{
				JFrame dist = new ProvinceDemo("District Selector");
    	        dist.setSize(350, 150);
    	        dist.setVisible(true);
			}
        }
        public class customFocusListener implements FocusListener{
        	public void focusGained(FocusEvent e) {
        		if(e.getSource()==emailText&&(emailText.getText().contentEquals("example@email.com")))
        		{emailText.setText("");}
        		if(e.getSource()==cnicNumber&&(cnicNumber.getText().contentEquals("13 Digits")))
        		{cnicNumber.setText("");}
        		if(e.getSource()==phoneNumber&&(phoneNumber.getText().contentEquals("14 Digits")))
        		{phoneNumber.setText("");}
        		/*if(e.getSource()==districtSelector&&(district_city.getText().contentEquals("")))
        		{district_city.setText(userInfo.Users_city);
        		district_province.setText(userInfo.Users_province);}
        		if (e.getSource()==day&&(day.getText().equals("Date")))
        		{day.setText("");}
        		if (e.getSource()==month&&(month.getText().equals("Month")))
        		{month.setText("");}
        		if(e.getSource()==year&&(year.getText().equals("Year")))
        		{year.setText("");}
        	*/	
        	}
        	
        	public void focusLost(FocusEvent e) {
        		if (emailText.getText().equals(""))
        		{emailText.setText("example@email.com");}
        		if (cnicNumber.getText().equals(""))
        		{cnicNumber.setText("13 Digits");}
        		if (phoneNumber.getText().equals(""))
        		{phoneNumber.setText("14 Digits");}
        		/*if (day.getText().equals(""))
        		{day.setText("Date");}
        		if (month.getText().equals(""))
        		{month.setText("Month");}
        		if(year.getText().equals(""))
        		{year.setText("Year");}*/
        	}

        }

}

