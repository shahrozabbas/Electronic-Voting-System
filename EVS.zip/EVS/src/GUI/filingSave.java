package GUI;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class filingSave{
	void saveUserLogin() throws IOException
	{
		String username = userInfo.Users_username;
		String password = userInfo.Users_password;
		FileWriter fw = new FileWriter("users.txt");
		fw.write(username);
		fw.write(password);
		fw.close();
	}
	int getUserLogin(String inputUsername, String inputPassword) throws IOException
	{
		String username="";
		String password="";
		int i = 0;
		boolean isUsername = true;
		boolean isPassword = false;
		int counter = 0;
		int usernameNo = 0;
		int passNo = 0;
		boolean foundUsername = false;
		boolean foundPassword = false;
		boolean exists=false;
		FileReader fr = new FileReader("users.txt");
		while ((i=fr.read())!=-1&&exists==false)
		{
			if (isUsername==true&&isPassword==false&&exists==false)
				{
					//System.out.println((char)i);
					if((char)i=='.')
					{
						isPassword=true;
						isUsername=false;
						usernameNo++;
						if(username==inputUsername)
						{foundUsername=true;}
					}
					else
						{username=username+(char)i;}
				}
			System.out.println("Username saved: "+username);
			
			
			if(isPassword==true&&isUsername==false&&exists==false)
				{
					//System.out.println((char)i);
					if ((char)i=='.'&&counter>1)
					{
						isPassword=false;
						isUsername=true;
						counter=0;
						passNo++;
						if(password==inputPassword&&foundUsername==true)
						{foundPassword=true;
						exists=true;}
						else
						{password="";
						username="";}
					}
					else if((char)i!='.')
					{password=password+(char)i;}
					counter++;
				}
			System.out.println("Password saved:"+password);
			if (exists==true)
			{System.out.println("found");
				return 1;}
		}
		fr.close();
		return 0;
	}
}
