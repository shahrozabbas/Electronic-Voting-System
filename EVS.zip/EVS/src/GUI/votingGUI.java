package GUI;

public class votingGUI {

}
