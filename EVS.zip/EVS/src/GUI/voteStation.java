package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;

public class voteStation extends JFrame implements ActionListener {
	JPanel panel = new JPanel();
	
	JLabel userDist = new JLabel("<html>Your District is: <br><br>"+userInfo.Users_city+", "+userInfo.Users_province+"</html>", SwingConstants.CENTER);
	JLabel candidate = new JLabel("Select a candidate to vote for:", SwingConstants.CENTER);
	JLabel cand = new JLabel("Candidate:");
	JLabel party = new JLabel("Party:");
	JLabel distBox = new JLabel(userInfo.Users_city+", "+userInfo.Users_province, SwingConstants.CENTER);

	JComboBox<String> candidateBox = new JComboBox<>(candidates.candidateList);
	JTextField partyBox = new JTextField();
	
	JButton selectButton = new JButton("Select");
	
	voteStation()
	{
		userDist.setBounds(0, 30, 500, 60);
		candidate.setBounds(0, 100, 500, 15);
		cand.setBounds(150, 140, 60, 15);
		candidateBox.setBounds(230, 137, 120, 20);
		party.setBounds(150, 180, 60, 15);
		partyBox.setBounds(230, 177, 120, 20);
		partyBox.setEditable(false);
		selectButton.setBounds(220, 210, 70, 30);
		
		panel.setLayout(null);
		panel.add(userDist);
		panel.add(candidate);
		panel.add(cand);
		panel.add(candidateBox);
		panel.add(party);
		panel.add(partyBox);
		panel.add(selectButton);
		
		candidateBox.addActionListener(this);
		selectButton.addActionListener(this);
		add(panel);
		
		setTitle("Voting Menu");
		setSize(500,300);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent e) {
		String candidateName = (String)candidateBox.getSelectedItem();
		if(candidateName=="Select")
		{partyBox.setText(null);}
		if(candidateName==candidates.candidate1)
		{partyBox.setText(candidates.party1);}
		if(candidateName==candidates.candidate2)
		{partyBox.setText(candidates.party2);}
		if(candidateName==candidates.candidate3)
		{partyBox.setText(candidates.party3);}
		if(e.getSource()==selectButton)
		{
			if(candidateBox.getSelectedItem()=="Select")
			{
				JOptionPane.showMessageDialog(panel, "Please Select a Candidate", "Cast Your Vote",JOptionPane.WARNING_MESSAGE);
			}
			else 
			{
				candidates.candidate_selected=(String)candidateBox.getSelectedItem();
				System.out.println(candidates.candidate_selected);
				setVisible(false);
				dispose();
				JOptionPane.showMessageDialog(panel, "Your Vote has been casted!", "Vote Casted", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
}
