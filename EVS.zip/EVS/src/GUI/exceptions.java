package GUI;

public class exceptions{
/*
	exception()
	  {
		  String message;
		message = "Username Taken";
	  }
	public void username(String message)
	{
		
	}
*/}
