package GUI;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class getUserInfo {
	getUserInfo(){
	String UserRecord="users.txt";
	try {
		BufferedReader myReader= new BufferedReader(new FileReader(UserRecord));
		myReader.read(userInfo.Users_username+"."+userInfo.Users_password+".");
		myReader.read(tempname+","+tempcnic+",");
		myReader.read(tempgender+","+tempreligion+",");
		myReader.read(tempfatherName+","+tempemail+",");
		myReader.read(tempphone+","+tempdob_date+",");
		myReader.read(tempdob_month+","+tempdob_year+",");
		myReader.read(temp_province+","+temp_city+",\n");
		myReader.close();
	} 
	catch (IOException e2) {
		e2.printStackTrace();
	}
}
	}
