package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import javax.swing.*;

public class accountDetails implements ActionListener{
	JFrame accountDetframe = new JFrame();
	JPanel accountDetPanel = new JPanel();
	
	JButton back = new JButton("Back");

	JLabel name = new JLabel("Name");
	JLabel username = new JLabel("Username");
	JLabel email = new JLabel("Email Address");
	JLabel cnic = new JLabel("CNIC");
	JLabel dob = new JLabel("Date of Birth");
	JLabel gender = new JLabel("Gender");
	JLabel religion = new JLabel("Religion");
	JLabel father = new JLabel("Father Name");
	JLabel phone = new JLabel("Phone Number");
	JLabel district = new JLabel("District");
	JLabel province = new JLabel("Province");
	JLabel city = new JLabel("City");
	
	JTextField name1 = new JTextField(userInfo.Users_name);
	JTextField username1 = new JTextField(userInfo.Users_username);
	JTextField email1 = new JTextField(userInfo.Users_email);
	JTextField cnic1 = new JTextField(userInfo.Users_cnic);
	JTextField dob1 = new JTextField(userInfo.Users_dob_date+"/"+userInfo.Users_dob_month+"/"+userInfo.Users_dob_year);
	JTextField gender1 = new JTextField(userInfo.Users_gender);
	JTextField religion1 = new JTextField(userInfo.Users_religion);
	JTextField father1 = new JTextField(userInfo.Users_fatherName);
	JTextField phone1 = new JTextField(userInfo.Users_phone);
	JTextField province1 = new JTextField(userInfo.Users_province);
	JTextField city1 = new JTextField(userInfo.Users_city);

	accountDetails() throws FileNotFoundException
	{/*
		String UserRecord ="users.txt";
		Scanner search = new Scanner(new BufferedReader(new FileReader(UserRecord)));
	    search.useDelimiter("[.]");
	    while (search.hasNextLine()){
	    }
		
		boolean found=false;
		Scanner s;
		String user,pwd;
		try {
			s = new Scanner(new File("accounts.txt"));
			s.useDelimiter("[.]");
			while(s.hasNextLine()&&found!=true)
			{
				user=s.next();
				pwd=s.next();
			}
		}
		catch(FileNotFoundException e1){}
		*/
		
		
		name.setBounds(10, 20, 100, 25);
		username.setBounds(10, 50, 100, 25);
		cnic.setBounds(10, 80, 100, 25);
		dob.setBounds(10, 110, 100, 25);
		gender.setBounds(10, 140, 100, 25);
		religion.setBounds(10, 170, 100, 25);
		father.setBounds(10, 200, 100, 25);
		phone.setBounds(10, 230, 100, 25);
		email.setBounds(10, 260, 100, 25);
		district.setBounds(170, 290, 100, 25);
		province.setBounds(10, 320, 100, 25);
		city.setBounds(10, 350, 100, 25);
		back.setBounds(145, 380, 100, 30);
		back.addActionListener(this);
		
		name1.setBounds(120, 20, 200, 25);
		username1.setBounds(120, 50, 200, 25);
		cnic1.setBounds(120, 80, 200, 25);
		dob1.setBounds(120, 110, 200, 25);
		gender1.setBounds(120, 140, 200, 25);
		religion1.setBounds(120, 170, 200, 25);
		father1.setBounds(120, 200, 200, 25);
		phone1.setBounds(120, 230, 200, 25);
		email1.setBounds(120, 260, 200, 25);
		province1.setBounds(120, 320, 200, 25);
		city1.setBounds(120, 350, 200, 25);
		
		name1.setEditable(false);
		username1.setEditable(false);
		cnic1.setEditable(false);
		dob1.setEditable(false);
		gender1.setEditable(false);
		religion1.setEditable(false);
		father1.setEditable(false);
		phone1.setEditable(false);
		email1.setEditable(false);
		province1.setEditable(false);
		city1.setEditable(false);
		
		accountDetPanel.setLayout(null);
		accountDetPanel.add(name);
		accountDetPanel.add(username);
		accountDetPanel.add(cnic);
		accountDetPanel.add(dob);
		accountDetPanel.add(gender);
		accountDetPanel.add(religion);
		accountDetPanel.add(father);
		accountDetPanel.add(phone);
		accountDetPanel.add(email);
		accountDetPanel.add(district);
		accountDetPanel.add(province);
		accountDetPanel.add(city);
		accountDetPanel.add(name1);
		accountDetPanel.add(username1);
		accountDetPanel.add(cnic1);
		accountDetPanel.add(dob1);
		accountDetPanel.add(gender1);
		accountDetPanel.add(religion1);
		accountDetPanel.add(father1);
		accountDetPanel.add(phone1);
		accountDetPanel.add(email1);
		accountDetPanel.add(province1);
		accountDetPanel.add(city1);
		accountDetPanel.add(back);

		accountDetframe.add(accountDetPanel);
		accountDetframe.setTitle("Account Details");
		accountDetframe.setSize(400, 700);
		accountDetframe.setLocationRelativeTo(null);
		accountDetframe.setVisible(true);
		accountDetframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==back)
		{
			accountDetframe.setVisible(false);
			accountDetframe.dispose();
		}
	}
}
