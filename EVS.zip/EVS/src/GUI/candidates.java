package GUI;

public class candidates {

	static String candidate1 = new String("Kashif Ghafoor");
	static String candidate2 = new String("Syed Muzammil");
	static String candidate3 = new String("Syed ALi");
	static String party1 = new String("PMLN");
	static String party2 = new String("PPP");
	static String party3 = new String("PTI");
	
	public static String[] candidateList = new String[] {"Select", candidate1, candidate2, candidate3};
	public static String[] partyList = new String[] {party1, party2, party3};
	
	static String candidate_selected = new String();
}
