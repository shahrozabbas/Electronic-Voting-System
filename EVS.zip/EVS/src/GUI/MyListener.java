package GUI;

import java.awt.List;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
 
public class MyListener implements ActionListener {
 
    JComboBox countries, cities;
 
    public MyListener(JComboBox countries, JComboBox cities) {
        this.countries = countries;
        this.cities = cities;
 
    }
 
    public void actionPerformed(ActionEvent e) {
 
        String button = e.getActionCommand();
        String country = "";
 
        if (countries.getSelectedIndex() == -1) {
            System.out.println("nothing selected");
            return;
        }
 
        else if (button.equals("Select")) {
            System.exit(0);
        }
 
        country = countries.getSelectedItem().toString();
 
        try {
            File file = new File("E:\\Programming\\Codes\\Java\\EVS\\"
                    + country.toString() + ".txt");
            int count = 0;
            BufferedReader in = new BufferedReader(new FileReader(file));
            String str;
            cities.removeAllItems();
            while ((str = in.readLine()) != null) {
                cities.addItem(str);
            }
        } catch (IOException ex) {
            System.out.println("A exception occured " + ex);
            return;
        }
 
    }
}