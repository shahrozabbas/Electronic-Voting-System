package Scrapped_Code;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class database {
	database() throws ClassNotFoundException, SQLException
	{
	Class.forName("org.h2.Driver");
	Connection connection;
	connection=DriverManager.getConnection("jdbc:h2:mem:test;MODE=MySQL;DB_CLOSE_DELAY=-1;IGNORECASE=TRUE;","sa","");
	String query="select * from voters where username=? and password=?";
    PreparedStatement statement=connection.prepareStatement(query);
    String username=userInfo.Users_username;
    String password=userInfo.Users_password;
    statement.setString(1, username);
    statement.setString(2, password);
    ResultSet set=statement.executeQuery();
    if(set.next())
    {
      JOptionPane.showMessageDialog(null, "Login Sucessfull");
      //write your code here
    }else
    {
      JOptionPane.showMessageDialog(null, "Invalid Username or Password");
      return;
    }
	}
}
